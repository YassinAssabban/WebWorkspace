<?php

class ContactManager
{

  private $db;

  public function __construct($db)
  {
    $this->db = $db;
  }

  public function getContacts()
  {
    $sql = "SELECT * from contact";
    $result = array();
    try {
      $select = $this->db->prepare($sql);
      $select->execute();
      $result = $select->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
      die($e);
    } finally {
      $select->closeCursor();
    }
    return $result;
  }

  public function getContact($id)
  {
    $sql = "SELECT * from contact WHERE id=:id";
    $result = array();
    try {
      $select = $this->db->prepare($sql);
      $select->execute(array('id' => $id));
      $result = $select->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
      die($e);
    } finally {
      $select->closeCursor();
    }
    return $result;
  }

  public function save(Contact $contact)
  {
    $sql = "INSERT INTO contact(`firstname`, `lastname`, `email`, `birthdate`, `phone`, `photo`) VALUES (:firstname, :lastname, :email, :birthdate, :phone, :photo)";
    if ($contact->getId() > 0) {
      $sql = "UPDATE contact set `firstname`=:firstname, `lastname`=:lastname, `email`=:email, `birthdate`=:birthdate, `phone`=:phone, `photo`=:photo WHERE id=:id";
    }
    try {
      $insert = $this->db->prepare($sql);
      $params = array(
        'firstname' => $contact->getFirstname(),
        'lastname' => $contact->getLastname(),
        'email' => $contact->getEmail(),
        'birthdate' => $contact->getBirthdate(),
        'phone' => $contact->getPhone(),
        'photo' => $contact->getPhoto(),
      );
      if ($contact->getId() > 0) {
        $params['id'] = $contact->getId();
      }
      $insert->execute($params);
      if ($contact->getId() <= 0) {
        $contact->setId($this->db->lastInsertId());
      }
    } catch (PDOException $e) {
      die($e);
    } finally {
      $insert->closeCursor();
    }
  }

  public function delete($id)
  {
    $sql = "DELETE FROM contact WHERE id=:id";
    try {
      $insert = $this->db->prepare($sql);
      $insert->execute(
        array(
          'id' => $id,
        )
      );
    } catch (PDOException $e) {
      die($e);
    } finally {
      $insert->closeCursor();
    }
  }

}