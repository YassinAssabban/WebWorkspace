<?php

class Contact implements JsonSerializable
{

  private $id;
  private $firstname;
  private $lastname;
  private $email;
  private $birthdate;
  private $phone;
  private $photo;

  /**
   * @return mixed
   */
  public function getFirstname()
  {
    return $this->firstname;
  }

  /**
   * @param mixed $firstname 
   * @return self
   */
  public function setFirstname($firstname): self
  {
    $this->firstname = $firstname;
    return $this;
  }

  /**
   * @return mixed
   */
  public function getLastname()
  {
    return $this->lastname;
  }

  /**
   * @param mixed $lastname 
   * @return self
   */
  public function setLastname($lastname): self
  {
    $this->lastname = $lastname;
    return $this;
  }

  /**
   * @return mixed
   */
  public function getEmail()
  {
    return $this->email;
  }

  /**
   * @param mixed $email 
   * @return self
   */
  public function setEmail($email): self
  {
    $this->email = $email;
    return $this;
  }

  /**
   * @return mixed
   */
  public function getBirthdate()
  {
    return $this->birthdate;
  }

  /**
   * @param mixed $birthdate 
   * @return self
   */
  public function setBirthdate($birthdate): self
  {
    $this->birthdate = $birthdate;
    return $this;
  }

  /**
   * @return mixed
   */
  public function getPhone()
  {
    return $this->phone;
  }

  /**
   * @param mixed $phone 
   * @return self
   */
  public function setPhone($phone): self
  {
    $this->phone = $phone;
    return $this;
  }

  /**
   * @return mixed
   */
  public function getPhoto()
  {
    return $this->photo;
  }

  /**
   * @param mixed $photo 
   * @return self
   */
  public function setPhoto($photo): self
  {
    $this->photo = $photo;
    return $this;
  }

  /**
   * @return mixed
   */
  public function getId()
  {
    return $this->id;
  }

  /**
   * @param mixed $id 
   * @return self
   */
  public function setId($id): self
  {
    $this->id = $id;
    return $this;
  }
  /**
   * Specify data which should be serialized to JSON
   * Serializes the object to a value that can be serialized natively by json_encode().
   * @return mixed Returns data which can be serialized by json_encode(), which is a value of any type other than a resource .
   */
  public function jsonSerialize()
  {
    return array(
      'id' => $this->getId(),
      'firstname' => $this->getFirstname(),
      'lastname' => $this->getLastname(),
      'email' => $this->getEmail(),
      'birthdate' => $this->getBirthdate(),
      'phone' => $this->getPhone(),
      'photo' => $this->getPhoto(),
    );
  }
}