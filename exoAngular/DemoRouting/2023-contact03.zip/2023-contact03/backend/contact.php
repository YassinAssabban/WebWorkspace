<?php
require_once('models/Contact.class.php');
require_once('managers/DBManager.php');
require_once('managers/ContactManager.php');

header("Access-Control-Allow-Origin: http://localhost:4200");
header("Access-Control-Allow-Headers: content-type");
header("Access-Control-Allow-Methods: GET,POST,PUT,DELETE");

$dbManager = new DBManager();
$pdo = $dbManager->connect();
$contactManager = new ContactManager($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  if (isset($_GET['id'])) {
    $contacts = $contactManager->getContact($_GET['id']);
  } else {
    $contacts = $contactManager->getContacts();
  }
  echo json_encode($contacts);
} else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $json_obj = json_decode(file_get_contents('php://input'), true);
  $contact = new Contact();
  $contact->setFirstname($json_obj['firstname']);
  $contact->setLastname($json_obj['lastname']);
  $contact->setEmail($json_obj['email']);
  $contact->setPhone($json_obj['phone']);
  $contact->setPhoto($json_obj['photo']);
  $contact->setBirthdate($json_obj['birthdate']);
  $contactManager->save($contact);
  echo json_encode($contact);
} else if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
  $json_obj = json_decode(file_get_contents('php://input'), true);
  if (isset($json_obj['id'])) {
    $contact = new Contact();
    $contact->setId($json_obj['id']);
    $contact->setFirstname($json_obj['firstname']);
    $contact->setLastname($json_obj['lastname']);
    $contact->setEmail($json_obj['email']);
    $contact->setPhone($json_obj['phone']);
    $contact->setPhoto($json_obj['photo']);
    $contact->setBirthdate($json_obj['birthdate']);
    $contactManager->save($contact);
    echo json_encode($contact);
  } else {
    http_response_code(400);
    echo 'Property id is mandatory for update contact';
  }
} else if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
  if (isset($_GET['id'])) {
    $contactManager->delete($_GET['id']);
  } else {
    http_response_code(400);
    echo 'Parameter id is missing';
  }
} else {

}