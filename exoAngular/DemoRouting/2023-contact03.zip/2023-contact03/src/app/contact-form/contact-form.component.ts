import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';
import { Contact } from '../contact';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css'],
})
export class ContactFormComponent implements OnInit {
  newContact: Contact = {
    id: -1,
    firstname: '',
    lastname: '',
    email: '',
    birthdate: '',
    phone: '',
  };

  constructor(
    private api: ApiService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.activatedRoute.params.subscribe((params) => {
      if (params['id']) {
        const sub = this.api.getContacts(params['id']).subscribe((contact) => {
          this.newContact = contact as Contact;
          sub.unsubscribe();
        });
      }
    });
  }

  saveNewContact() {
    if (this.newContact.id > 0) {
      const sub = this.api
        .updateContact(this.newContact)
        .subscribe((contact) => {
          this.newContact = contact;
          this.router.navigate(['home']);
          sub.unsubscribe();
        });
    } else {
      const sub = this.api.addContact(this.newContact).subscribe((contact) => {
        this.newContact = contact;
        this.router.navigate(['home']);
        sub.unsubscribe();
      });
    }
  }
}
