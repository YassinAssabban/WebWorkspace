export const environment = {
  apiUrl: 'https://helha.dev.local/angular/2023-contact03/backend/contact.php',
};
