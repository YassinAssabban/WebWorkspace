import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'helha-example';
  pageNumber: number = 0;

  gotoPage1() {
    this.pageNumber = 1;
  }

  gotoPage2() {
    this.pageNumber = 2;
  }
}
