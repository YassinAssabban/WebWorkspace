import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css'],
})
export class AboutComponent implements OnInit {
  @Input()
  label: string = 'No action';

  @Output()
  resetValue: EventEmitter<string> = new EventEmitter();

  constructor() {}

  ngOnInit(): void {}

  clickButton() {
    // alert('Click sur le bouton');
    this.resetValue.emit('');
  }
}
