export const environment = {
  backendUrl: 'http://mon-backend-helha.com',
};
