export const environment = {
  backendUrl: 'http://jsonplaceholder.typicode.com/todos',
};
