import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { FormsModule } from '@angular/forms';
import {
  ActivatedRouteSnapshot,
  CanActivateFn,
  Route,
  RouterModule,
  RouterStateSnapshot,
} from '@angular/router';
import { AboutComponent } from './about/about.component';
import { ActionsComponent } from './actions/actions.component';
import { AppComponent } from './app.component';
import { PageIndexComponent } from './page-index/page-index.component';
import { Page1Component } from './page1/page1.component';
import { Page2Component } from './page2/page2.component';
import { Page404Component } from './page404/page404.component';
import { SecurityGuard } from './security.guard';

const securityGuardFn: CanActivateFn = (
  route: ActivatedRouteSnapshot,
  state: RouterStateSnapshot
) => {
  return true;
};

const routes: Route[] = [
  { path: '', component: PageIndexComponent },
  { path: 'page1', component: Page1Component, canActivate: [securityGuardFn] },
  { path: 'page2', component: Page2Component, canActivate: [SecurityGuard] },
  { path: '**', component: Page404Component },
];

@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    ActionsComponent,
    Page1Component,
    Page2Component,
    Page404Component,
    PageIndexComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
