import { Component, OnInit } from '@angular/core';
import { Todo } from '../todo';
import { TodoService } from '../todo.service';

@Component({
  selector: 'app-page2',
  templateUrl: './page2.component.html',
  styleUrls: ['./page2.component.css'],
})
export class Page2Component implements OnInit {
  myTodoList!: Todo[];

  constructor(private service: TodoService) {}

  ngOnInit(): void {
    const subscription = this.service.getTodo().subscribe(
      (todoList) => {
        this.myTodoList = todoList;
        subscription.unsubscribe();
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
