import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Todo } from '../todo';
import { TodoService } from '../todo.service';

@Component({
  selector: 'app-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css'],
})
export class Page1Component implements OnInit {
  todoList!: Observable<Todo[]>;

  constructor(private service: TodoService) {}

  ngOnInit(): void {
    this.todoList = this.service.getTodo();
  }
}
