<!DOCTYPE html>
<html lang="fr">
<head>
  <title>News</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="icon" type="image/png" href="logo/monitor.png" />
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
                <div class="lisere">
                  <a href="index.php"><img src="logo/logo2.png" class="logolis"></a>
                  <a href="panier.php" class="panier"><img src="logo/basket.png" width="40px" height="40px"></a>
                </div>


<div style="color: #ddd;background-color:#282E34;text-align:center;padding:50px 80px;text-align: justify;">
  <h3 class="titre-news">Made In Config recrute</h3>
  <p>En tant que vendeur - magasinier (H/F), vous êtes en charge de : Accueil et gestion de la clientèle (magasin, téléphone, e-mail ...)Garantir la réception et le contrôle des marchandises Préparation des commandes Rangement du magasin et des endroits de stockage Vous êtes orienté client Vous avez la fibre commerciale Vous avez obligatoirement des connaissances en mécanique Des connaissances en allemand sont un sérieux atout Une mission intérim en vue d’un contrat à durée indéterminée Un salaire attractif en fonction de vos compétences Une ambiance de travaille dynamique et agréable Vous travaillez dans une entreprise familiale qui propose des formations en continue</p>
</div>
 
<div class="bgimg-2">
</div>

<div style="position:relative;">
  <div style="color:#ddd;background-color:#282E34;text-align:center;padding:50px 80px;text-align: justify;">
  <p>Decouvrez notre nouvelle boutique sur Charleroi !!</p>
  </div>
</div>

<div class="bgimg-3">
</div>

<div style="position:relative;">
  <div style="color:#ddd;background-color:#282E34;text-align:center;padding:50px 80px;text-align: justify;">
  <p>Livraison bientôt disponible.</p>
  </div>
</div>

<div class="bgimg-4">
</div>
          <footer>
              <p>Copyright © Made In Config. Inc.</p>
              <p>Créé par Yassin Assabban dans le cadre d'études d'IG à la l'HELHa.</p>
              <p>Attention toutes les informations de ce site web sont fausses rien n'est à vendre ici.</p>
              <p>Toute reproduction même partielle de ce site web ou de son contenu est strictement interdite.</p>  
      </footer>
      </body>
</html>

</body>
</html>