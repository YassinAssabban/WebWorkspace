document.getElementById('p1').innerHTML = 'Langue du navigateur : ' + navigator.language ;
document.getElementById('p2').innerHTML = ' Cookie du navigateur activé : ' + navigator.cookieEnabled ;
document.getElementById('p3').innerHTML = ' Location : ' + navigator.geolocation ;
document.getElementById('p4').innerHTML = ' navigateur en ligne : ' + navigator.onLine ;
document.getElementById('p5').innerHTML = ' platorme du navigateur : ' + navigator.platform ;
document.getElementById('p6').innerHTML = ' navigateur user agent : ' + navigator.userAgent ;
// document.getElementById('p7').innerHTML = ' navigateur : ' + navigator. ;
// document.getElementById('p8').innerHTML = ' navigateur : ' + navigator. ;

document.getElementById('p9').innerHTML = ' Height screen avail : ' + screen.availHeight ;
document.getElementById('p10').innerHTML = ' Width screen avail : ' + screen.availWidth ;
document.getElementById('p11').innerHTML = ' Color depth : ' + screen.colorDepth ;
document.getElementById('p12').innerHTML = ' Height screen : ' + screen.height ;
document.getElementById('p13').innerHTML = ' Width screen : ' + screen.width ;
document.getElementById('p14').innerHTML = ' Pixel depth : ' + screen.pixelDepth ;