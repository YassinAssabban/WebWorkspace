alert("3" + 7); // 10
alert("trois" + 7); // trois 7
alert("9" == 9); // true
alert("9" === 9); // false
alert("10+10" == 20); // false
alert(null == undefined); // false
alert(null === undefined); // false
alert(false == 0); // true
alert(false == null); // false
alert(0 ? 1 : 2); // 2
alert(2 ? 1 : 0);// 
alert("false" == true); // false
alert(("" == false) == 221);
alert(3 + 4 * 5); alert(5 && "bonjour");
alert("bonjour" || 5);
alert((0 + undefined) ? "0" + undefined : 0 + undefined);
alert("Salut");