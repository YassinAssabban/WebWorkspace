let texte1 = "Ceci est écrit en javascript";
let texte2 = "Et je me débrouille très bien";

let extrait = texte1.substring(11,13);
let concat = extrait + " " + texte2;

alert(concat);