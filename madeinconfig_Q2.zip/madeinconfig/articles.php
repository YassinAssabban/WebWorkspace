<?php 
$article1 = array($_POST[''])
?>