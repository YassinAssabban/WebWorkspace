<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Macbook's</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="icon" type="image/png" href="logo/monitor.png" />
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>
<body>
	<header>
		<div class="lisere">
			<a href="index.php"><img src="logo/logo2.png" class="logolis"></a>
			<a href="panier.php" class="panier"><img src="logo/basket.png" width="40px" height="40px"></a>
		</div>
		<nav>
					<div class="navbar">
								  <a href="index.php">Accueil</a>
								  <a href="news.php">News</a>
						<div class="dropdown">
								    <button class="dropbtn">Composants
								      <i class="fa fa-caret-down"></i>
								    </button>
							<div class="dropdown-content">
								    <div class="header">
								        <h2>Composants</h2>
								    </div>   
								<div class="row-nav">
									<div class="column-nav">
								 		<h3>Composants PC</h3>
								   		<a href="proco.php">Processeur</a>
								   		<a href="cm.php">Carte mère</a>
							    		<a href="kitevo.php">Kit Evo</a>
									</div>
									<div class="column-nav">
										<h3 class="cacherpoint">.</h3>
										<a href="memoire.php">Mémoire</a>
										<a href="cg.php">Carte Graphique</a>
										<a href="boitierpc.php">Boitier</a>
									</div>
									<div class="column-nav">
										<h3 class="cacherpoint">.</h3>
									  	<a href="alim.php">Alimentation</a>
										<a href="ssd.php">SSD</a>
										<a href="disquedur.php">Disque Dur</a>
									</div>
									<div class="column-nav">
										<h3>Refroidissement PC</h3>
									  	<a href="ventil.php">Ventilateur PC</a>
										<a href="ventir.php">Ventirad PC</a>
										<a href="water.php">Watercooling</a>
									</div>
								</div>
							</div>
						</div> 
						<div class="dropdown">
								    <button class="dropbtn">Produits
								      <i class="fa fa-caret-down"></i>
								    </button>
							<div class="dropdown-content">
								    <div class="header">
								        <h2>Produits</h2>
								    </div>   
								<div class="row-nav">
									<div class="column-nav">
								   		<h3>Périphériques</h3>
								   		<a href="screen.php">Ecran PC</a>
               							<a href="clavier.php">Clavier</a>
               							<a href="mouse.php">Souris</a>
									</div>
									<div class="column-nav">
										<h3>Apple</h3>
										<a href="macbook.php">Macbook</a>
              							<a href="ipad.php">Ipad</a>
              							<a href="iphone.php">Iphone</a>
									</div>
									<div class="column-nav">
									</div>
									<div class="column-nav">
									</div>
								</div>
							</div>
						</div>
						<?php
									session_start();

									if(empty($_SESSION['user'])) {
										echo "
										<div class=\"connect\"><a href=\"signUp.php\">Sign Up</a></div>
										<div class=\"connect\"><a href=\"connect.php\">Sign In</a></div> ";
									} else {
										$sess = $_SESSION['user'];
										echo "<div class=\"connect\"><a href=\"#\">Bonjour ";
										echo "$sess";
										echo "!</a></div> <div class=\"connect\"><a href=\"deconnexion.php\">Deconnexion</a></div>";
									}

								?>

								<div class="search-container">
							    	<form action="/action_page.php">
							      		<input type="text" placeholder="Search.." name="search">
							     	 	<button type="submit"><i class="fa fa-search"></i></button>
							    	</form>
							  </div>
					</div>
		</nav>
	</header>
    	<div class="row">
						  
						  <div class="column">
						  	<img src="img/apple/AIRM1.png">
						    <div class="card">
						      <h3>Apple MacBook Air M1 Argent 8Go/256 Go (MGN93FN/A)</h3>
						      <br>
						      <p>Le MacBook Air, le plus fin et léger des portables Apple, est métamorphosé par la puissante puce Apple M1. Avec un gain de performances spectaculaire pour le CPU et le GPU. Et jusqu'à 18 heures d'autonomie. Le portable Apple le plus fin et le plus léger est métamorphosé par la puce Apple M1.
						      </p>
						      <h1 class="price">1 129€<sup class="cent">93</sup></h1><br>
						      <input type="button" class="btnbasket" name="#" value="        AJOUTER AU PANIER  ">						    </div>
						  </div>

						   <div class="column">
						   	<img src="img/apple/AIR.png">
						    <div class="card">
						      <h3>Apple MacBook Air (2020) 13" avec écran Retina Argent (MVH42FN/A)</h3>
						      <br>
						      <p>Le nouveau MacBook Air (2020) c'est : Un écran Retina avec affichage True Tone, un processeur Intel Core i5 de 10e génération, 8 Go de RAM, un SSD au format M.2 PCIe, un trackpad Force Touch, deux ports Thunderbolt 3 et le capteur d'empreinte digitale Touch ID.</p>
						      <h1 class="price">1 279€<sup class="cent">95</sup></h1><br>
						      <input type="button" class="btnbasket" name="#" value="        AJOUTER AU PANIER  ">						    </div>
						  </div>
						  
						  <div class="column">
						   	<img src="img/apple/PROM1.png">
						    <div class="card">
						      <h3>Apple MacBook Pro M1 13.3" Gris sidéral 8Go/256 Go (MYD82FN/A)</h3>
						      <br>
						      <p>Le MacBook Pro 13 pouces est complètement transformé par la puce Apple M1. Il offre désormais jusqu'à 2,8 fois plus de puissance de traitement, des performances graphiques 5 fois plus rapides et jusqu'à 20 heures d'autonomie, un record sur Mac.</p>
						      <h1 class="price">1 449€<sup class="cent">96</sup></h1><br>
						      <input type="button" class="btnbasket" name="#" value="        AJOUTER AU PANIER  ">						    </div>
						  </div>

						  <div class="column">
						   	<img src="img/apple/PRO.png">
						    <div class="card">
						      <h3>Apple MacBook Pro 16" avec Touch Bar Argent (MVVL2FN/A)</h3>
						      <br>
						      <p>Gagnez en confort avec l'Apple MacBook Pro avec écran Retina de 16 pouces ! Avec un affichage de haute qualité, une autonomie longue durée et un clavier Magic Keyboard avec Touch Bar, il offre un parfait confort de travail !</p>
						      <h1 class="price">2 689€<sup class="cent">94</sup></h1><br>
						      <input type="button" class="btnbasket" name="#" value="        AJOUTER AU PANIER  ">						    </div>
						  </div>



			</div>
<!--
https://www.ldlc.com/fr-be/fiche/PB00390401.php
https://www.ldlc.com/fr-be/fiche/PB00325639.php
https://www.ldlc.com/fr-be/fiche/PB00390440.php
https://www.ldlc.com/fr-be/fiche/PB00281646.php

-->
<footer>
			        <p>Copyright © Made In Config. Inc.</p>
			        <p>Créé par Yassin Assabban dans le cadre d'études d'IG à la l'HELHa.</p>
			        <p>Attention toutes les informations de ce site web sont fausses rien n'est à vendre ici.</p>
			        <p>Toute reproduction même partielle de ce site web ou de son contenu est strictement interdite.</p>  
			</footer>
			</body>
</html>