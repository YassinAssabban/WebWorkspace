<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Asus Carte-Mère</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="icon" type="image/png" href="logo/monitor.png" />
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>
<body>
	<header>
		<div class="lisere">
			<a href="index.php"><img src="logo/logo2.png" class="logolis"></a>
			<a href="panier.php" class="panier"><img src="logo/basket.png" width="40px" height="40px"></a>
		</div>
		<nav>
					<div class="navbar">
								  <a href="index.php">Accueil</a>
								  <a href="news.php">News</a>
						<div class="dropdown">
								    <button class="dropbtn">Composants
								      <i class="fa fa-caret-down"></i>
								    </button>
							<div class="dropdown-content">
								    <div class="header">
								        <h2>Composants</h2>
								    </div>   
								<div class="row-nav">
									<div class="column-nav">
								 		<h3>Composants PC</h3>
								   		<a href="proco.php">Processeur</a>
								   		<a href="cm.php">Carte mère</a>
							    		<a href="kitevo.php">Kit Evo</a>
									</div>
									<div class="column-nav">
										<h3 class="cacherpoint">.</h3>
										<a href="memoire.php">Mémoire</a>
										<a href="cg.php">Carte Graphique</a>
										<a href="boitierpc.php">Boitier</a>
									</div>
									<div class="column-nav">
										<h3 class="cacherpoint">.</h3>
									  	<a href="alim.php">Alimentation</a>
										<a href="ssd.php">SSD</a>
										<a href="disquedur.php">Disque Dur</a>
									</div>
									<div class="column-nav">
										<h3>Refroidissement PC</h3>
									  	<a href="ventil.php">Ventilateur PC</a>
										<a href="ventir.php">Ventirad PC</a>
										<a href="water.php">Watercooling</a>
									</div>
								</div>
							</div>
						</div> 
						<div class="dropdown">
								    <button class="dropbtn">Produits
								      <i class="fa fa-caret-down"></i>
								    </button>
							<div class="dropdown-content">
								    <div class="header">
								        <h2>Produits</h2>
								    </div>   
								<div class="row-nav">
									<div class="column-nav">
								   		<h3>Périphériques</h3>
								   		<a href="screen.php">Ecran PC</a>
               							<a href="clavier.php">Clavier</a>
               							<a href="mouse.php">Souris</a>
									</div>
									<div class="column-nav">
										<h3>Apple</h3>
										<a href="macbook.php">Macbook</a>
              							<a href="ipad.php">Ipad</a>
              							<a href="iphone.php">Iphone</a>
									</div>
									<div class="column-nav">
									</div>
									<div class="column-nav">
									</div>
								</div>
							</div>
						</div>
						<?php
									session_start();

									if(empty($_SESSION['user'])) {
										echo "
										<div class=\"connect\"><a href=\"signUp.php\">Sign Up</a></div>
										<div class=\"connect\"><a href=\"connect.php\">Sign In</a></div> ";
									} else {
										$sess = $_SESSION['user'];
										echo "<div class=\"connect\"><a href=\"#\">Bonjour ";
										echo "$sess";
										echo "!</a></div> <div class=\"connect\"><a href=\"deconnexion.php\">Deconnexion</a></div>";
									}

								?> 

								<div class="search-container">
							    	<form action="/action_page.php">
							      		<input type="text" placeholder="Search.." name="search">
							     	 	<button type="submit"><i class="fa fa-search"></i></button>
							    	</form>
							  </div>
					</div>
		</nav>
	</header>
				<div class="row">
						  <div class="column">
						  	<img src="img/cm/ASUSB450PLUS.png">
						    <div class="card">
						      <h3>ASUS PRIME B450-PLUS</h3>
						      <br>
						      <p>Grâce au support des processeurs AMD Ryzen sur socket AMD AM4, à la prise en charge de la mémoire vive DDR4, des cartes graphiques PCI-Express 3.0, des disques SATA 6Gb/s et M.2 (SATA et PCI-E), la carte mère ASUS PRIME B450-PLUS est à la pointe de la technologie.</p>
						     <h1 class="price">114€<sup class="cent">95</sup></h1><br>
						      <input type="button" class="btnbasket" name="#" value="        AJOUTER AU PANIER  ">						    </div>
						  </div>

						  <div class="column">
						  	<img src="img/cm/asusrogstrixz390h.png">
						    <div class="card">
						      <h3>ASUS ROG STRIX Z390-H GAMING</h3>
						      <br>
						      <p>La carte mère ASUS ROG STRIX Z390-H GAMING est faite pour accueillir les processeurs Intel Core de 9ème génération (Intel Coffee Lake Refresh). Basée sur le chipset Intel Z390 Express, elle permettra l'assemblage d'une configuration Gaming équipée d'un processeur performant.
						      </p>
						      <h1 class="price">219€<sup class="cent">95</sup></h1><br>
						      <input type="button" class="btnbasket" name="#" value="        AJOUTER AU PANIER  ">						    </div>
						  </div>
						  
						  <div class="column">
						  	<img src="img/cm/asusstrixb450i.png">
						    <div class="card">
						      <h3>ASUS STRIX B450-I GAMING</h3>
						      <br>
						      <p>La carte mère ASUS STRIX B450-I GAMING est idéale pour concevoir un PC puissant et à l'aise dans toutes les situations : multimédia, bureautique et jeux vidéo, vous pourrez assembler la configuration de vos rêves avec un AMD Ryzen (Pinnacle Ridge, Raven Ridge ou Summit Ridge).
						      </p>
						      <h1 class="price">194€<sup class="cent">96</sup></h1><br>
						      <input type="button" class="btnbasket" name="#" value="        AJOUTER AU PANIER  ">						    </div>
						  </div>

						   <div class="column">
						   	<img src="img/cm/asustufz390plus.png">
						    <div class="card">
						      <h3>ASUS TUF Z390-PLUS GAMING (WI-FI)</h3>
						      <br>
						      <p>La carte mère ASUS TUF Z390-PLUS GAMING (WI-FI) est faite pour accueillir les processeurs Intel Core de 9ème génération (Intel Coffee Lake Refresh). Basée sur le chipset Intel Z390 Express, elle permettra l'assemblage d'une configuration Gaming équipée d'un processeur performant.</p>
						      <h1 class="price">139€<sup class="cent">95</sup></h1><br>
						      <input type="button" class="btnbasket" name="#" value="        AJOUTER AU PANIER  ">						    </div>
						  </div>



			</div>
<!--
	https://www.ldlc.com/fr-be/fiche/PB00254092.php
	https://www.ldlc.com/fr-be/fiche/PB00257631.php
	https://www.ldlc.com/fr-be/fiche/PB00254148.php
	https://www.ldlc.com/fr-be/fiche/PB00257612.php
-->

<footer>
			        <p>Copyright © Made In Config. Inc.</p>
			        <p>Créé par Yassin Assabban dans le cadre d'études d'IG à la l'HELHa.</p>
			        <p>Attention toutes les informations de ce site web sont fausses rien n'est à vendre ici.</p>
			        <p>Toute reproduction même partielle de ce site web ou de son contenu est strictement interdite.</p>  
			</footer>
			</body>
</html>