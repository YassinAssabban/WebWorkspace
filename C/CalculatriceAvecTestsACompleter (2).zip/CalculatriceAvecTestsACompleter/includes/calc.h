#include <string.h>
#include <ctype.h>
#include <math.h>
#define DIM 100

double calculerResultat(char chaine[], int dim, char erreur[]);