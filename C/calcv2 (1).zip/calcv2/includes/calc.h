#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#define DIM 100

// main
int recommencer(void);

// calculateur
double calculerResultat(char chaine[], int dim, char erreur[]);