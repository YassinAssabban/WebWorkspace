#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#define DIM 100

void empiler(double valeur);
double depiler();
int pileVide();
void initialiserPile();
