import { HelhaPipe } from './helha.pipe';

describe('HelhaPipe', () => {
  it('create an instance', () => {
    const pipe = new HelhaPipe();
    expect(pipe).toBeTruthy();
  });
});
