export interface Appointment {
  id?: string;
  nom?: string;
  prenom?: string;
  startDate?: string;
  endDate?: string;
}
